Rails.application.routes.draw do
  get "sign_up" => "users#new", :as => "sign_up"
  resources :users
  resources :sessions
  resources :articles do
  	resources :comments
  end

  root 'home#index'
  get 'home/index'
  get 'contacts/index'
  post 'contacts/index', to: 'contacts#create', as: :contacts
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
