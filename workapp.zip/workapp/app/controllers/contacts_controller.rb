class ContactsController < ApplicationController
  def index
  	@contacts=Contact.new
  end

   def create
  	@contacts = Contact.new(params_contact)
  	if @contacts.save
  		flash[:success] ="Susccess Add Records"
  		redirect_back fallback_location: "0.0.0.0:3000/articles/"
  	else
  		flash[:error] = "Data not Valid"
  		render 'new'
  	end
  end

  private
  def params_contact
  	params.require(:contact).permit(:email, :message)
  end
end