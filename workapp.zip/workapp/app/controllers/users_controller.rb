class UsersController < ApplicationController
  def index
  end

  def new
    @user = User.new
  end

  def edit
  end

  def create
  	@user = User.new(params_user)
      if @user.save
        begin
            ConfirmationMailer.confirm_email(@user).deliver_now
        rescue
            flash[:notice] = "activation instruction fails send to your email"
        end
        redirect_to root_url
        flash[:notice] = "activation instruction has send to #{@user.email}"

    else
        flash[:error] = "data not valid"
        render "new"
      #   format.html { redirect_to(root_url, :notice => 'User was successfully created.') }
      # else
      #   format.html { render :action => "new" }
      # end
    end
  end

  private
  def params_user
     params.require(:user).permit(:username, :email, :password, :password_confirmation, :humanizer_answer, :humanizer_question_id)
  end
end
