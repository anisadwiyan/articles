class CommentsController < ApplicationController
  

  def new
  end

  def edit
  end

  def create 
    respond_to do |format|
      @article = Article.find(params[:article_id])
      @comment = @article.comments.create(params_comment)
      if @comment.save
        format.js { @article }
        redirect_back fallback_location: "0.0.0.0:3000/articles"
      else
        format.js { @article = Article.find(params[:article_id]) }
        render 'new'
      end
    end
  end


  private
  def params_comment
  	params.require(:comment).permit(:content, :article_id, :user_id)
  end
end
