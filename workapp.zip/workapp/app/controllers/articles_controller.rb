class ArticlesController < ApplicationController
  before_action :check_current_user, only: [:new, :create, :edit, :update, :destroy]
  def index
    @articles = Article.page(params[:page]).per(1)
    respond_to do |format|
      if params[:search].present?
        format.js {
          @articles = Article.where("title like ? or content like ?", "%#{params[:search]}%", "%#{params[:search]}%").page(params[:page]).per(2)
        }
        format.html
      else
        format.html
      end
    end
  end

  def new
  	@articles=Article.new
  end

  def edit
  	@articles=Article.find_by_id(params[:id])
  end

  def destroy
  	@articles = Article.find_by_id(params[:id])
    if @articles.destroy
        flash[:notice] = "Success Delete a Records"
        redirect_to action: 'index'
    else
        flash[:error] = "fails delete a records"
        redirect_to action: 'index'
    end
  end

  def update
    @articles = Article.find_by_id(params[:id])
    if @articles.update(params_article)
       flash[:notice] = "Success Update Records"
       redirect_to action: 'index'
    else
       flash[:error] = "data not valid"
       render 'edit'
    end
  end

  def create
  	@articles = Article.new(params_article)
  	if @articles.save
  		flash[:success] ="Susccess Add Records"
  		redirect_to action: 'index'
  	else
  		flash[:error] = "Data not Valid"
  		render 'new'
  	end
  end

  def show
  	@articles = Article.find_by_id(params[:id])
    @comments = Comment.new
  end

  private
  def params_article
  	params.require(:article).permit(:title, :content, :status)
  end
end
