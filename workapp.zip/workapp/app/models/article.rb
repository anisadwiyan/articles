class Article < ActiveRecord::Base
	validates :content, presence:true, length:{minimum:5}
	scope :status_active, ->{where(status: 'publish')}
	has_many :comments, dependent: :destroy
end


